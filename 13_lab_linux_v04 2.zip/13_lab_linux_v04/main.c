#include "import.h"
#include <stdio.h>
#include <stdlib.h>

//char *CheckStatus();

int main()
{
	printf("%s", CheckStatus());
	
	return 0;
}
